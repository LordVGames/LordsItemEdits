﻿using System;
using System.Collections.Generic;
using System.Text;
using Mono.Cecil.Cil;
using MonoMod.Cil;
using MonoDetour;
using MonoDetour.HookGen;
using MonoDetour.Cil;
using RoR2;
using LordsItemEdits.MultiItemEdits;

namespace LordsItemEdits.ModSupport.Starstorm2
{
    [MonoDetourTargets(typeof(SS2.Items.ErraticGadget))]
    internal static class ErraticGadget
    {
        [MonoDetourHookInitialize]
        internal static void Setup()
        {
            //On.SS2.Items.ErraticGadget.
        }

        private static void JustDoDoubleDamage_SimpleLightningStrikeOrb(ILManipulationInfo info)
        {
            ILWeaver w = new(info);
            ILLabel skipFireMissile = w.DefineLabel();


            w.MatchRelaxed(
                x => x.MatchCallvirt(out _),
                x => x.MatchLdcI4(0),
                x => x.MatchBle(out _) && w.SetCurrentTo(x)
            ).ThrowIfFailure();
            w.InsertAfterCurrent(w.CreateCall(TEST));
        }

        private static void TEST()
        {
            Log.Warning("TEST");
        }
    }
}