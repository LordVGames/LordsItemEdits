## 0.3.2

- All items
- - Fixed description edits still applying if an item's edit is disabled

## 0.3.1

- Electric Boomerang
- - Blacklisted it from enemies since players can't be stunned

## 0.3.0

- Polylute
- - Made it stack damage instead of hit count (another change to help late-game performance)

- Electric Boomerang
- - Got a damage buff, travels further and faster, and is guranteed to proc off of skills that can stun (meant to synergize with those stunning skills instead of being a perma-stun and proc chain beast)

## 0.2.1

- Changed package description (forgot to earlier)
- - I'll update the icon later idc rn

## 0.2.0

- Void Dios
- - Made the void ally you spawn in as have 50% less hp because the normal hp made you insanely tanky if you had pearls and was super OP with nkuhanas

- ATG
- Armed Backpack (Starstorm 2)
- - Made missiles fire out like plasma shrimp does in order to help peformance late-game

- Pocket I.C.B.M
- - Affected missiles deal triple damage instead of firing 2 extra missiles to help performance late-game
- - Supports other generic missiles and a few modded skills that had an ICBM effect

- Erratic Gadget (Starstorm 2)
- - Fixed some erratic gadget chain lightning procs being able to infinitely proc chain with itself and other procs
- - Affected lightning procs get their damage doubled instead of double proccing to help performance late-game

- Molten Perforator
- - Makes enemies explode in a 16m radius that also scales with enemy size (mainly helps performance but also helps balance a bit)

- Executive Card
- - Now works more like an actual equipment (with an 80 second cooldown): Gain 2 stacks of a buff and buying something uses up a stack of the buff to do the normal executive card effect

- Bottled Chaos
- - Now also gives a 35% equipment cooldown reduction (cooldown reduction does not stack)

## 0.1.0

- First W.I.P release