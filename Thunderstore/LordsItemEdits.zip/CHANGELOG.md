## 1.0.0

- Void Dios
- - Made the void ally you spawn in as have 50% less hp
- - After spawning in as a void ally while having even a few items that give +% hp, you're insanely hard to kill and can do insane damage with nkuhanas. 50% less hp for these playable void allies should make them more balanced.

- ATG
- - Made it fire out like plasma shrimp does in order to help peformance late-game


## 0.1.0

- First W.I.P release