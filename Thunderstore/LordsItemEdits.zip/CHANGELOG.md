## 1.0.0

- Void Dios
- - Made the void ally you spawn in as have 50% less hp
- - After spawning in as a void ally while having even a few items that give +% hp, you're insanely hard to kill and can do insane damage with nkuhanas. 50% less hp for these playable void allies should make them more balanced.

- ATG
- Armed Backpack (Starstorm 2)
- - Made it fire out like plasma shrimp does in order to help peformance late-game

- Pocket I.C.B.M
- - Affected missiles deal triple damage instead of firing 2 extra missiles to help performance late-game

- Erratic Gadget (Starstorm 2)
- - Fixed some erratic gadget chain lightning procs being able to infinitely proc chain with itself and other procs
- - Affected lightning procs get their damage doubled instead of double proccing to help performance late-game

## 0.1.0

- First W.I.P release